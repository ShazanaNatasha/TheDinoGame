package userinterface;

import javax.swing.JFrame;

public class Mainmenu extends JFrame{
	
	public static final int SCREEN_WIDTH = 600;
	private GameScreen gameScreen;
	
	
	
}
